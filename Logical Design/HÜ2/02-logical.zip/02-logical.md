# Assignment 2: Logical Design

**Deadline**: Monday, 16 November 2026, 01:30 PM

**Name**: *Insert your name here!*

**Matriculation Number**: *Insert your matriculation number here!*


## Important Notice
- Do not forget to mark the tasks that you solved in the corresponding checkmark list on Moodle.

- Submit a PDF report with your solution. In addition, submit a single plain text file consisting of SQL DDL and DML statements (SQL file).

- Name the submitted files according to the following naming convention, where *MatriculationNumber* is to be replaced with your matriculation number:
  - **02-logical-k*MatriculationNumber*.pdf**
  - **02-logical-k*MatriculationNumber*.sql**

- Use comments in the SQL file to document assumptions and add explanations.

- If anything is unclear, make reasonable assumptions, document these assumptions, and/or post a question on the *Discussions* forum on Moodle.


## Task 1: Measurement (40 points)
The fact schema in **Figure 1** in Dimensional Fact Model (DFM) notation allows for the multidimensional analysis of sensor data.
You should implement the fact schema as a star schema for the PostgreSQL rational database management system.

Define a logical model for the Measurement fact class in **Figure 1** using SQL *CREATE TABLE* and *DROP TABLE* statements.
Use SQL *INSERT* statements to illustrate what the contents look like and to test your implementation.
The provided SQL *INSERT* statements should insert a couple of rows into each table for illustration purposes.
The provided SQL *DROP TABLE* statements should allow for easy resetting of your schema.

Furthermore, consider the following points:
- The dimension tables should **generally** be denormalized (i.e., in a single table), except for shared hierarchies, which should not be duplicated. Furthermore, in some cases and where appropriate, you may deviate from that rule.
- For each level, use a surrogate key and a natural key (name) attribute (e.g., *agent_id* and *agent_name* for the *Agent* level), unless it does not make sense to do so.
- Do not use a surrogate key for the fact table.
- Define primary key, unique key, and foreign key constraints where appropriate.
- All attributes mut be non-nullable (i.e., define NOT NULL constraints).
- Choose reasonable data types for the attributes.
- Follow the guidelines in literature concerning the representation of date/time dimensions. For example, the granularity of time is in hours, minutes, and seconds (e.g., a measurement may be recorded at 15:30:45).
- Realize multiple arcs using a bridge table. You may normalize parts of the dimension table to realize the bridge table.
- Represent degenerate dimensions consisting of a single level using a junk table.

**Notes**:
- The SQL statements must be executable on a PostgreSQL database in order for you to claim points for the assignment and make a check to the task.
- Include the SQL *CREATE TABLE*, *DROP TABLE*, and *INSERT* statements in your SQL submission file.
- Include your SQL *CREATE TABLE* statements in the PDF report.

<figure id="fig:1-dfm_measurement">
  <img src="resources/dfm_measurement.png" alt="" width="100%">
  <figcaption><strong>Figure 1:</strong> Fact schema of sensor measurement</figcaption>
</figure>

Insert your **SQL CREATE TABLE statements** in the following fenced code block!
```
...
```

## Task 2: Slowly Changing Dimensions (20 points)
Consider the Agent and Location dimensions for measurements from **Task 1** as slowly changing dimension.
Transform the **Agent** dimension table according to the *SCD Type 2* pattern to track the evolution of different versions of the tuples over time.
Transform the **Location** dimension table according to the *SCD Type 3* pattern, specifically for the **FunctionalArea** attribute, tracking its current and previous values.

Provide SQL *CREATE TABLE* and *DROP TABLE* statements for the updated schema.
Add your transformed tables to your SQL submission file; a separate file with the SCD tables is not necessary.
Provide SQL *INSERT* and *UPDATE* statements to load example data into the table and change existing tuples to illustrate the change of attributes over time.

**Notes**:
- The SQL statements must be executable on a PostgreSQL database in order for you to claim points for the assignment and make a check to the task.
- Include the SQL *CREATE TABLE*, *DROP TABLE*, *INSERT*, and *UPDATE* statements in your SQL submission file.
- Include your SQL *CREATE TABLE* statements in the PDF report.

Insert your **SQL CREATE TABLE statements** in the following fenced code block!
```
...
```


## Task 3: Passenger Bookings (40 points)
The fact schema in **Figure 2** in Dimensional Fact Model (DFM) notation allows for the multidimensional analysis of passenger bookings.
You should implement the fact schema as a star schema for the PostgreSQL rational database management system.

Define a logical model for the PassengerBooking fact class in **Figure 2** using SQL *CREATE TABLE* and *DROP TABLE* statements.
Use SQL *INSERT* statements to illustrate what the contents look like and to test your implementation.
The provided SQL *INSERT* statements should insert a couple of rows into each table for illustration purposes.
The provided SQL *DROP TABLE* statements should allow for easy resetting of your schema.

Furthermore, consider the following points:
- The dimension tables should **generally** be denormalized (i.e., in a single table), except for shared hierarchies, which should not be duplicated. Furthermore, in some cases and where appropriate, you may deviate from that rule.
- For each level, use a surrogate key and a natural key (name) attribute (e.g., *passenger_id* and *passenger_name* for the *passenger* level), unless it does not make sense to do so.
- Do not use a surrogate key for the fact table.
- Define primary key, unique key, and foreign key constraints where appropriate.
- All attributes mut be non-nullable (i.e., define NOT NULL constraints).
- Choose reasonable data types for the attributes.
- Follow the guidelines in literature concerning the representation of the date dimension. Explicitly represent individual components of the date for convenience.
- Realize multiple arcs using a bridge table. You may normalize parts of the dimension table to realize the bridge table.
- Represent degenerate dimensions consisting of a single level using a junk table.

**Notes**:
- The SQL statements must be executable on a PostgreSQL database in order for you to claim points for the assignment and make a check to the task.
- Include the SQL *CREATE TABLE*, *DROP TABLE*, and *INSERT* statements in your SQL submission file.
- Include your SQL *CREATE TABLE* statements in the PDF report.

<figure id="fig:2-dfm_passenger-booking">
  <img src="resources/dfm_passenger-booking.png" alt="" width="100%">
  <figcaption><strong>Figure 2:</strong> Fact schema of passenger booking</figcaption>
</figure>

Insert your **SQL CREATE TABLE statements** in the following fenced code block!
```
...
```